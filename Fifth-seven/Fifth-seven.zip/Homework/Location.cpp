#include "Location.h"
#include <iostream>
#include <map>
#include <unordered_map>
using namespace std;

void location::addExit(char direction, location &destination) {
	if (direction == 'N') north = &destination;
	else if (direction == 'S') south = &destination;
	else if (direction == 'W') west = &destination;
	else if (direction == 'E') east = &destination;
	else cout << "Direction error! Please input N/S/W/E!"<<endl;
}
void location:: addMonster(Monster &m) {
	if (monster_list.find(&m) != monster_list.end()) monster_list[&m]++;
	else monster_list.insert(make_pair(&m, 1));
	//cout << "Add successfully!" << endl;
}
void location:: delMonster(Monster &monster_del) {
	if (monster_list.size() == 0) {
		cout << "There is no monster!";
		return;
	}
	unordered_map<Monster*,int>::iterator itm;
	for (itm = monster_list.begin();itm != monster_list.end();itm++) {
		Monster* monster = itm->first;
		if (monster->getName() == monster_del.getName()) {
			itm->second--;
			if (itm->second == 0) monster_list.erase(itm);
			//cout << "Delete successfully!";
			return ;
		}
	}
	cout << "Not Exit!";
}
void location:: getExits() {
	if (north != nullptr) cout << "North: " << north->getName() <<endl;
	else cout << "North is forbidden!"<<endl;
	if (south !=nullptr) cout<< "South: " << south->getName()  <<endl;
	else cout << "South is forbidden!"<<endl;
	if (west != nullptr) cout << "West: " << west->getName() <<  endl;
	else cout << "West is forbidden!"<<endl;
	if (east != nullptr) cout << "East: " << east->getName() <<  endl;
	else cout << "East is forbidden!"<<endl;
}
void location:: addItm(weapon &itm) {
	if (weapon_list.find(&itm) != weapon_list.end()) weapon_list[&itm]++;
	else weapon_list.insert(make_pair(&itm, 1));
	//cout << "Add successfully!" << endl;
}
void location::addItm(potion &itm) {
	if (potion_list.find(&itm) != potion_list.end()) potion_list[&itm]++;
	else potion_list.insert(make_pair(&itm, 1));
	//cout << "Add successfully!" << endl;
}
void location::addItm(treasure &itm) {
	if (treasure_list.find(&itm) != treasure_list.end()) treasure_list[&itm]++;
	else treasure_list.insert(make_pair(&itm, 1));
	//cout << "Add successfully!" << endl;
}
void location::addItm(armour& itm) {
	if (armour_list.find(&itm) != armour_list.end()) armour_list[&itm]++;
	else armour_list.insert(make_pair(&itm, 1));
}
void location::addSalary(treasure& itm) {
	if (salary_treasure_list.find(&itm) != salary_treasure_list.end()) salary_treasure_list[&itm]++;
	else salary_treasure_list.insert(make_pair(&itm, 1));
}
void location::addSalary(potion& itm) {
	if (salary_potion_list.find(&itm) != salary_potion_list.end()) salary_potion_list[&itm]++;
	else salary_potion_list.insert(make_pair(&itm, 1));
}
void location::setDirection(char d, location &target) {
	if (d == 'N') {
		this->north = &target;
		//cout << this->getNorth()->getDescription() << endl;
	}
	if (d == 'S') {
		this->south = &target;
		//cout << this->getSouth()->getDescription() << endl;
	}
	if (d == 'W') {
		this->west = &target;
		//cout << this->getWest()->getDescription() << endl;
	}
	if (d == 'E') {
		this->east = &target;
		//cout << east->getDescription() << endl;
	}
}
void location::show() {
	vector<string> result;
	if (weapon_list.size() != 0) result.push_back(weapon_list.begin()->first->getName());
	if (treasure_list.size() != 0) result.push_back(treasure_list.begin()->first->getName());
	if (potion_list.size() != 0) result.push_back(treasure_list.begin()->first->getName());
	if (armour_list.size() != 0) result.push_back(armour_list.begin()->first->getName());
	if (result.size() == 0) cout << "There is no source!" << endl;
	else {
		for (int i = 0;i < result.size() - 1;i++) { cout << "There is a "<< result[i]<<", "; }
		cout << result[result.size() - 1] << "."<<endl;
	}
	if (monster_list.size() > 0) {
		unordered_map<Monster*, int>::iterator itm = monster_list.begin();
		for (;itm != monster_list.end();itm++) {
			cout << "the " << itm->first->getName() << " is here" << endl;
		}
	}
	if (monster_list.size() == 0&&(salary_treasure_list.size()!=0||salary_potion_list.size()!=0)) {
		result.clear();
		unordered_map<treasure*, int>::iterator itm1 = salary_treasure_list.begin();
		unordered_map<potion*, int>::iterator itm2 = salary_potion_list.begin();
		for (;itm1 != salary_treasure_list.end();itm1++) { result.push_back(itm1->first->getName()); }
		for (;itm2 != salary_potion_list.end();itm2++) { result.push_back(itm2->first->getName()); }
		for (int i = 0;i < result.size() - 1;i++) { cout << "There is a " << result[i] << ", "; }
		cout << result[result.size() - 1] << "." << endl;
	}
}
void location::delete_source() {
	weapon_list.clear();
	potion_list.clear();
	treasure_list.clear();
	armour_list.clear();
}
void location::delete_salary() {
	salary_potion_list.clear();
	salary_treasure_list.clear();
}