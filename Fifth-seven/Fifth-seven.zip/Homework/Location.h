#pragma once
#include <vector>
#include <iostream>
#include <unordered_map>
using namespace std;
#include "Character.h"
#include "Itm.h"

class location {
private:
	string name;
	string description;
	location *north;
	location *south;
	location *west;
	location *east;
	unordered_map<Monster * ,int> monster_list;
	unordered_map<weapon * ,int> weapon_list;
	unordered_map<potion * , int> potion_list;
	unordered_map<treasure * , int> treasure_list;
	unordered_map<treasure*, int> salary_treasure_list;
	unordered_map<potion*, int> salary_potion_list;
	unordered_map<armour*, int> armour_list;
public:
	location(string Name, string Description) :name(Name), description(Description), north(nullptr),south(nullptr),east(nullptr),west(nullptr) {}
	void setDirection(char d, location &target);
	void setName(string Name) { name = Name; }
	string getName() { return name; }
	void setDescription(string Description) { description = Description; }
	string getDescription() { return description; }
	void addExit(char direction, location &destination);
	void addMonster(Monster &monster);
	void delMonster(Monster &monster);
	void getExits();
	void addItm(weapon &itm);
	void addItm(potion &itm);
	void addItm(treasure &itm);
	void addItm(armour& itm);
	void addSalary(treasure& itm);
	void addSalary(potion& itm);
	void show();
	void delete_source();
	void delete_salary();
	location* getNorth() {  return north; }
	location* getSouth() { return south; }
	location* getWest() { return west; }
	location* getEast() { return east; }
	unordered_map<weapon*, int> getWeapon_List() { return weapon_list; }
	unordered_map<potion*, int> getPotion_List() { return potion_list; }
	unordered_map<treasure*, int> getTreasure_List() { return treasure_list; }
	unordered_map<Monster*, int> getMonster_List() { return monster_list; }
	unordered_map<treasure*, int> getSalary_treasure_list() { return salary_treasure_list; }
	unordered_map<potion*, int> getSalary_potion_list() { return salary_potion_list; }
	unordered_map<armour*, int> getArmour_List() { return armour_list; }
};
