#pragma once
#include <iostream>
using namespace std;
#ifndef Itm_H
#define Itm_H
class Itm {
private:
	string name;
public:
	Itm(string Name):name(Name){}
	void setName(string Name) { name = Name; }
	string getName() { return name; }
};
#endif

#ifndef armour_H
#define armour_H
class armour :public Itm {
private:
	int defend;
public:
	armour(string name, int de) :Itm(name), defend(de) {}
	int getDefend() { return defend; }
	void setDefend(int d) { defend = d; }
};
#endif

#ifndef weapon_H
#define weapon_H
class weapon:public Itm{
private:
	int power;
public:
	weapon(string name,int Power):Itm(name),power(Power){}
	int getPower() { return power; }
	void setPower(int Power) { power = Power; }
};
#endif

#ifndef potion_H
#define potion_H
class potion :public Itm {
private:
	int strength;
public:
	potion(string name, int Strength):Itm(name),strength(Strength){}
	int getStrength() { return strength; }
	void setStrength(int Strength) { strength = Strength; }
};
#endif

#ifndef treasure_H
#define treasure_H
class treasure :public Itm {
private:
	int value;
public:
	treasure(string name, int Value):Itm(name),value(Value){}
	int getValue() { return value; }
	void setValue(int Value) { value = Value; }
};
#endif