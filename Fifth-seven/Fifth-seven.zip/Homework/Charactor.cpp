#include "Character.h"
#include "Itm.h"
#include <iostream>
#include <map>
using namespace std;
int rollDice() {
	return 1 + rand() % (5);
}
void Player::collect_weapon(weapon& itm) {
	if (weapon_list.find(&itm) == weapon_list.end()) weapon_list.insert(make_pair(&itm, 1));
	else weapon_list[&itm]++;
	cout << "You collect the " << itm.getName() << endl;
}
void Player::collect_armour(armour& itm) {
	if(armour_list.find(&itm)==armour_list.end()) armour_list.insert(make_pair(&itm, 1));
	else armour_list[&itm]++;
	cout << "You collect the " << itm.getName() << endl;
}
void Player::collect_potion(potion& itm) {
	if (potion_list.find(&itm) == potion_list.end()) potion_list.insert(make_pair(&itm, 1));
	else potion_list[&itm]++;
	cout << "You collect the " << itm.getName() << endl;
}
void Player::collect_treasure(treasure& itm) {
	if (treasure_list.find(&itm) == treasure_list.end())treasure_list.insert(make_pair(&itm, 1));
	else treasure_list[&itm]++;
	cout << "You collect the " << itm.getName() << endl;
}
void Player::show() {
	cout << "Score: " << score << " Health: " << getHealthy_level() << endl;
	cout << "Weapon:" << endl;
	if (weapon_list.size() == 0) cout << "none." << endl;
	else {
		map<string, int>result;
		unordered_map<weapon * , int>::iterator itm;
		for (itm = weapon_list.begin();itm != weapon_list.end();itm++) {
			result.insert(make_pair(itm->first->getName(), itm->first->getPower()));
		}
		map<string, int>::iterator itm1;
		for (itm1 = result.begin();itm1 != result.end();itm1++) {
			cout << itm1->first << " (+" << itm1->second << ")"<<endl;
		}
	}
	cout << "Potion:" << endl;
	if (potion_list.size() == 0) cout << "none." << endl;
	else {
		map<string, int>result;
		unordered_map<potion*, int>::iterator itm;
		for (itm = potion_list.begin();itm != potion_list.end();itm++) {
			result.insert(make_pair(itm->first->getName(), itm->first->getStrength()));
		}
		map<string, int>::iterator itm1;
		for (itm1 = result.begin();itm1 != result.end();itm1++) {
			cout << itm1->first << " (+" << itm1->second << ")" << endl;
		}
	}
	cout << "Treasure:" << endl;
	if (treasure_list.size() == 0) cout << "none." << endl;
	else {
		map<string, int>result;
		unordered_map<treasure*, int>::iterator itm;
		for (itm = treasure_list.begin();itm != treasure_list.end();itm++) {
			result.insert(make_pair(itm->first->getName(), itm->first->getValue()));
		}
		map<string, int>::iterator itm1;
		for (itm1 = result.begin();itm1 != result.end();itm1++) {
			cout << itm1->first << " (+" << itm1->second << ")" << endl;
		}
	}
	cout << "Armour:" << endl;
	if (armour_list.size() == 0) cout << "none." << endl;
	else {
		map<string, int>result;
		unordered_map<armour*, int>::iterator itm;
		for (itm = armour_list.begin();itm !=armour_list.end();itm++) {
			result.insert(make_pair(itm->first->getName(), itm->first->getDefend()));
		}
		map<string, int>::iterator itm1;
		for (itm1 = result.begin();itm1 != result.end();itm1++) {
			cout << itm1->first << " (+" << itm1->second << ")" << endl;
		}
	}
}
void Player::drink_potion() {
	unordered_map<potion*, int>::iterator itm = potion_list.begin();
	int sum = 0;
	for (;itm != potion_list.end();itm++) { sum += itm->first->getStrength(); }
	delete_potion();
	setHitPoint(getHitPoint()+sum);
}
int Player::getWeapon() {
	int result = 0;
	unordered_map<weapon*, int>::iterator itm = weapon_list.begin();
	for (;itm != weapon_list.end();itm++) { if (itm->first->getPower() > result) result = itm->first->getPower(); }
	return result;
}
int Player::getDefend() {
	int result = 0;
	unordered_map<armour*, int>::iterator itm = armour_list.begin();
	for (;itm != armour_list.end();itm++) {  result += itm->first->getDefend(); }
	return result;
}
bool Player::fight(Monster &monster) {
	if (monster.getName() == "boss") cout << "Welcome to the final fight, the Boss have " << monster.getHitPoint() << " HitPoints!" << endl;
	cout << "Engaging the " << monster.getName() << " in combat..." << endl;
	cout << "the " << monster.getName() << " (" << monster.getHitPoint() << ")" << endl;
	cout << "Hero vs the " << monster.getName()<<endl;
	int i = 1;int power_num = getWeapon();
	int defend_num = getDefend();
	while (getHitPoint() > 0 && monster.getHitPoint() > 0) {
		cout << "--------------------" << endl;
		cout << "Round " << i++ << endl;
		int m = rollDice();
		int protect = 0 + rand() % (defend_num-1);
		takeHit(m * 2-protect);
		int n = rollDice();
		monster.takeHit(n + power_num);
		cout << getHitPoint() << "   " << monster.getHitPoint() << endl;
	}
	if (getHitPoint() <= 0) return false;
	else cout << "You have beaten the " << monster.getName()<<endl;
	return true;
}