#pragma once
#include "Itm.h"
#include <vector>
#include <iostream>
#include <unordered_map>
using namespace std;

class Character {
private:
	string Name;
	int HitPoint;
	int defend;
	int Healthy_level;
public:
	Character(string name, int hitpoint, int healthy_level) :Name(name), HitPoint(hitpoint), Healthy_level(healthy_level) { defend = 0; }
	void setName(string name) { Name = name; }
	string getName() { return Name; }
	void setHitPoint(int n) { HitPoint = n; }
	int getHitPoint() { return HitPoint; }
	void setHealty_level(int n) { Healthy_level = n; }
	int getHealthy_level() { return Healthy_level; }
	int getDefend() { return defend; }
	void setDefend(int n) { defend = n; }
};

class Monster:public Character {
private:
	unordered_map<armour*, int> armour_list;
public:
	Monster(string name, int hitpoint):Character(name, hitpoint, 100){}
	void takeHit(int n) { setHitPoint(getHitPoint() - n); }
};

class Player :public Character {
private:
	int score;
	unordered_map<weapon*, int> weapon_list;
	unordered_map<potion*, int> potion_list;
	unordered_map<treasure*, int> treasure_list;
	unordered_map<armour*, int> armour_list;

public:
	Player(string name, int hitpoint, int healthy_level, int s) :Character(name, hitpoint, healthy_level), score(s) {}
	int getScore() { return score; }
	void collect_weapon(weapon& itm);
	void collect_potion(potion& itm);
	void collect_armour(armour& itm);
	void collect_treasure(treasure& itm);
	void show();
	void drink_potion();
	void delete_potion() { potion_list.clear(); };
	bool fight(Monster& monster);
	void takeHit(int n) { setHitPoint(getHitPoint() - n); }
	int getWeapon();
	int getDefend();
	unordered_map<weapon*, int> getWeapon_list() { return weapon_list; }
	unordered_map<potion*, int> getPotion_list() { return potion_list; }
	unordered_map<armour*, int> getArmour_list() { return armour_list; }
};
