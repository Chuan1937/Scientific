﻿#include <iostream>
#include<unordered_map>
#include "Character.h"
#include "Itm.h"
#include "Location.h"
using namespace std;

int main()
{
    cout << "Welcome to enter the Adventure Game! The aim is to defeat the Boss, but you score points for defeating mosters along the way."<<endl;
    cout << "You can use the commands:" << endl;
    cout << "N S W E Inventory Inv Drink Collect Fight Quit ..." << endl << endl;
    cout  << "--------------------------------------------------------------------------------------------------------"<<endl<<endl;
    string order;
    location cave("cave", "You are in a cave, this place is full of danger!");
    location temple("temple", "You are in a temple, this place is a bit quiet!");
    location dungeon("dungeon", "You are in a dungeon, this place seems a bit oppressvie!");
    location castle("castle", "You are in a castle, this place is full of treasure!");
    location clearing("clearing", "You are in a clearing, it is a still evening");
    location hall("hall", "You are in a hall, this place seems to have nothing!");
    location garden("garden", "You are in a garden, the trees seems to be strange!");
    location library("library", "You are in a library, this place is full of books!");
    location forest("forest", "You are in a forest, the trees here are very lush!");
    location house("house", "You are in a house, but it seems that no one lives here!");
    location ruins("ruins", "You are in ruins, there are many good things buried here!");
    location field("filed", "You are in a filed, this place is a bit of danger!");
    treasure emerald("emerald", 40);
    treasure sapphire("sapphire", 40);
    treasure diamond("diamond", 60);
    treasure golden_ring("treasure chest", 2000);
    treasure bag_of_coins("bag of coins", 50);
    treasure ruby("ruby", 10);
    treasure cup("cup", 20);
    treasure key("key", 100);
    treasure book("book", 150);
    potion green_healing("green healing", 500);
    potion red_healing("red healing", 40);
    potion purple_healing("purple healing", 30);
    potion blue_healing("blue healing", 20);
    weapon dagger("dagger", 5);
    weapon sword("sword", 6);
    weapon stick("stick", 1);
    weapon club("club", 3);
    armour ringmail("ringmail", 5);
    armour chainmail("chainmail", 7);
    armour shield("shield", 4);
    armour breastplate("breastplate", 11);
    armour helmet("helmet", 12);
    armour gauntlet("gauntlet", 8);
    weapon crossbow("crossbow", 10);
    Monster goblin("goblin", 10);
    Monster zombie("zombie", 8);
    Monster banshee("banshee", 7);
    Monster vampire("vampire", 9);
    Monster dragon("dragon", 15);
    Monster orc("orc", 12);
    Monster spectre("spectre", 5);
    Monster ghoul("ghoul", 10);
    Monster boss("boss", 18);
    ruins.setDirection('N', castle);
    castle.setDirection('N', temple);castle.setDirection('N', ruins);castle.setDirection('W', dungeon);
    dungeon.setDirection('N', field);dungeon.setDirection('E', castle);
    cave.setDirection('E', field);
    field.setDirection('W', cave);field.setDirection('E', forest);field.setDirection('S', dungeon);
    forest.setDirection('W', field);forest.setDirection('N', temple);forest.setDirection('S', castle);
    temple.setDirection('S', forest);temple.setDirection('E', clearing);
    clearing.setDirection('W', temple);clearing.setDirection('E', house);
    house.setDirection('W', clearing);house.setDirection('E', library);house.setDirection('S', hall);
    library.setDirection('W', house);library.setDirection('S', garden);
    hall.setDirection('N', house);hall.setDirection('E', garden);
    garden.setDirection('W', hall);garden.setDirection('N', library);
    cave.addItm(emerald);
    field.addItm(sapphire);field.addItm(dagger);
    dungeon.addItm(red_healing);
    temple.addItm(diamond);temple.addItm(sword);
    castle.addItm(golden_ring);castle.addItm(stick);castle.addSalary(cup);castle.addSalary(book);castle.addSalary(key);castle.addSalary(green_healing);
    ruins.addItm(purple_healing);
    clearing.addItm(club);
    hall.addItm(bag_of_coins);hall.addItm(blue_healing);
    garden.addItm(ruby);garden.addItm(crossbow);
    field.addMonster(goblin);
    dungeon.addMonster(zombie);
    forest.addMonster(banshee);
    castle.addMonster(vampire);
    ruins.addMonster(dragon);
    house.addMonster(orc);house.addMonster(spectre);
    garden.addMonster(ghoul);
    cave.addMonster(boss);
    clearing.addItm(ringmail);
    cave.addItm(chainmail);
    field.addItm(shield);
    forest.addItm(breastplate);
    garden.addItm(helmet);
    hall.addItm(gauntlet);
    Player player("Tom",5,100,0);
    location* position = nullptr;
    unordered_map<Player*, location*> player_position;
    player_position.insert(make_pair(&player, &clearing));

    /*
    Start
    */
    while (cave.getMonster_List().size() > 0) {
        position = player_position[&player];
        cout << position->getDescription()<<endl;
        cout << "Exits:"<<endl;
        position->getExits();
        position->show();
        cin >> order;
        if (order == "Quit") break;
        if (order == "N") {
            if (position->getNorth() == nullptr) cout << "This direction is unavailable, please input again!" << endl;
            else player_position[&player] = position->getNorth(); 
        }
        else if (order == "S") {
            if (position->getSouth() == nullptr) cout << "This direction is unavailable, please input again!" << endl;
            else player_position[&player] = position->getSouth();
        }
        else if (order == "W") {
            if (position->getWest() == nullptr) cout << "This direction is unavailable, please input again!" << endl;
            else player_position[&player] = position->getWest(); 
        }
        else if (order == "E") {
            if (position->getEast() == nullptr) cout << "This direction is unavailable, please input again!" << endl;
            else player_position[&player] = position->getEast();
        }
        else if (order == "Drink") {
            if (player.getPotion_list().size() == 0) cout << "You have no potion!" << endl;
            else player.drink_potion();
        }
        else if (order == "Collect") {
            cout << "Collecting itms..."<<endl;
            if (position->getTreasure_List().size() == 0 && position->getWeapon_List().size() == 0 && position->getTreasure_List().size() == 0) {
                cout << "Sorry, there is nothing!" << endl;
            }
            else {
                if (position->getTreasure_List().size() != 0) {
                    treasure *temp = position->getTreasure_List().begin()->first;
                    player.collect_treasure(*temp);
                }
                if (position->getWeapon_List().size() != 0) {
                    weapon* temp = position->getWeapon_List().begin()->first;
                    player.collect_weapon(*temp);
                }
                if (position->getPotion_List().size() != 0) {
                    potion* temp = position->getPotion_List().begin()->first;
                    player.collect_potion(*temp);
                }
                if (position->getArmour_List().size() != 0) {
                    armour* temp = position->getArmour_List().begin()->first;
                    player.collect_armour(*temp);
                }
                if (position->getMonster_List().size() == 0 && (position->getSalary_treasure_list().size() != 0 || position->getSalary_potion_list().size() != 0)) {
                    if (position->getSalary_treasure_list().size() != 0) {
                        unordered_map<treasure*, int>::iterator itm1 = position->getSalary_treasure_list().begin();
                        treasure* temp1 = nullptr;;
                        for (;itm1 != position->getSalary_treasure_list().end();itm1++) {
                            temp1 = itm1->first;
                            player.collect_treasure(*temp1);
                        }
                    }
                    if (position->getSalary_potion_list().size() != 0) {
                        unordered_map<potion*, int>::iterator itm2 = position->getSalary_potion_list().begin();
                        potion* temp2 = nullptr;
                        for (;itm2 != position->getSalary_potion_list().end();itm2++) {
                            temp2 = itm2->first;
                            player.collect_potion(*temp2);
                        }
                    }
                    position->delete_salary();
                }
                position->delete_source();
            }
        }
        else if (order == "Inv" || order == "Inventory") {
            player.show();
        }
        else if (order == "Fight") {
            unordered_map<Monster*, int> list = position->getMonster_List();
            if (list.size() == 0) cout << "There is no monster!" << endl;
            else {
                int size = list.size();
                Monster* temp = list.begin()->first;
                unordered_map<Monster*, int>::iterator itm = list.begin();
                for (;itm != list.end();itm++) {
                    if (itm->first->getHitPoint() > temp->getHitPoint()) {
                        temp = itm->first;
                    }
                }
                if (player.fight(*temp) == false) break;
                else position->delMonster(*temp);
            }
        }
        else cout<<"Wrong order!"<<endl;
        cout << "--------------------------------------------------------------------------------------------------------" << endl;
    }
    cout << "Game Over!" << endl << "Your score is " << player.getScore();
    return 0;
}
