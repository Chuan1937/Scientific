#ifndef POTION_H
#define POTION_H

#include "Item.h"

class Potion : public Item {
public:
    Potion(const std::string &name, int strength);
    int getStrength() const;

private:
    int strength;
};

#endif // POTION_H
