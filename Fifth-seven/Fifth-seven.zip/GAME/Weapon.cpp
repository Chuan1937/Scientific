#include "Weapon.h"

Weapon::Weapon(const std::string &name, int power) : Item(name), power(power) {}

int Weapon::getPower() const {
    return power;
}
