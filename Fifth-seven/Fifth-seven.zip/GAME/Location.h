#ifndef LOCATION_H
#define LOCATION_H

#include <string>
#include <vector>
#include <map>
#include "Item.h" // Assuming Item is the base class for specific items like Potion, Weapon, Treasure
#include "Character.h" // Assuming Character class is defined, used here for monsters
#include "Monster.h" 
#include <memory>

class Location {
public:
    Location(const std::string &name = "", const std::string &description = "");

    // Setters and getters for name and description
    void setName(const std::string &name);
    std::string getName() const;
    void setDescription(const std::string &description);
    std::string getDescription() const;

    // Management of exits
    void addExit(const std::string &direction, Location *location);
    void getExits() const;

    // Management of items
    void addItem(Item *item);
    //void addItem(std::unique_ptr<Item> item);
    void delItem(Item *item);
    std::vector<Item*> getItems() const;
    void clearItems();
    void listItems() const;

    // Management of monsters
    void addMonster(Monster* monster);
    void listMonsters() const;
    void delMonster(Character *monster);

    // Methods for managing monsters
    std::vector<Monster*>& getMonsters();
    Monster& getStrongestMonster();
    void removeMonster(Monster& monster);

private:
    std::string name;
    std::string description;
    std::vector<Item*> items;
    //std::vector<std::unique_ptr<Item>> items; 
    std::vector<Monster*> monsters; 
    std::map<std::string, Location*> exits;

    // Helper function to display sorted items by type
    template <typename T>
    void listItemsOfType() const;
};

#endif // LOCATION_H
