#include "Player.h"
#include "Potion.h"
#include "Treasure.h"
#include <algorithm>
#include <iostream>
#include <cstdlib>  // For rand() and srand()
#include <ctime>    // For time()

// Roll dice function
int rollDice() {
    return (std::rand() % 6) + 1;
}

Player::Player(const std::string &name, int hitPoints) : Character(name, hitPoints), score(0) {}



bool Player::combat(Monster& monster) {
    while (this->getHitPoints() > 0 && monster.getHitPoints() > 0) {
        // Monster's turn to attack
        int monsterDamage = rollDice() * 2;
        this->takeHit(monsterDamage);
        std::cout << "The " << monster.getName() << " deals " << monsterDamage << " damage!" << std::endl;

        // Check if player is defeated
        if (this->getHitPoints() <= 0) {
            std::cout << "You have been defeated!" << std::endl;
            return false;
        }

        // Player's turn to retaliate
        int playerDamage = rollDice() + this->getHighestWeaponPower(); // Assuming Player class has this function
        monster.takeHit(playerDamage);
        std::cout << "You deal " << playerDamage << " damage to the " << monster.getName() << "!" << std::endl;

        // Display hitpoints after each round
        std::cout << "Your hitpoints: " << this->getHitPoints() << std::endl;
        std::cout << monster.getName() << "'s hitpoints: " << monster.getHitPoints() << std::endl;
    }
    // Return true if player wins, false otherwise
    return this->getHitPoints() > 0;
}


int Player::getHighestWeaponPower() const {
    int maxPower = 0;
    for (const auto& weapon : weapons) {
        if (weapon->getPower() > maxPower) {
            maxPower = weapon->getPower();
        }
    }
    return maxPower;
}

void Player::collectItem(std::unique_ptr<Item> item) {
    // Check the type of item and add it to the corresponding inventory
    if (Weapon* weapon = dynamic_cast<Weapon*>(item.get())) {
        weapons.push_back(std::unique_ptr<Weapon>(weapon));
    } else {
        inventory.push_back(std::move(item));
    }
}

void Player::drinkPotions() {
    int totalHealing = 0;
    auto it = std::remove_if(inventory.begin(), inventory.end(), 
                             [&totalHealing](const std::unique_ptr<Item>& item) {
        if (Potion* potion = dynamic_cast<Potion*>(item.get())) {
            totalHealing += potion->getStrength();
            return true; // Remove potion from inventory
        }
        return false;
    });

    inventory.erase(it, inventory.end());
    this->setHitPoints(this->getHitPoints() + totalHealing);
}

void Player::listInventory() const {
    // List all items in the inventory
    for (const auto& item : inventory) {
        std::cout << item->getName() << ", ";
    }
    std::cout << std::endl;

    // List all weapons in the inventory
    for (const auto& weapon : weapons) {
        std::cout << weapon->getName() << " (Power: " << weapon->getPower() << "), ";
    }
    std::cout << std::endl;
}

int Player::getScore() const {
    return score;
}

void Player::sortInventory() {
    // Sorts the inventory alphabetically by the item's name
    std::sort(inventory.begin(), inventory.end(),
              [](const std::unique_ptr<Item>& a, const std::unique_ptr<Item>& b) {
                  return a->getName() < b->getName();
              });
}

void Player::increaseScore(int points) {
    score += points;
}

void Player::collectItems(const std::vector<Item*>& items) {
    for (Item* item : items) {
        if (Weapon* weapon = dynamic_cast<Weapon*>(item)) {
            // Assume Player stores weapons separately
            weapons.push_back(std::unique_ptr<Weapon>(weapon));
        } else {
            // For other items
            inventory.push_back(std::unique_ptr<Item>(item));
        }
    }
}