#include "Monster.h"

Monster::Monster(const std::string &name, int hitPoints, int value) : Character(name, hitPoints), value(value) {}

int Monster::getValue() const {
    return value;
}
