#ifndef MONSTER_H
#define MONSTER_H

#include "Character.h"

class Monster : public Character {
public:
    Monster(const std::string &name, int hitPoints, int value);

    int getValue() const;

private:
    int value;
};

#endif // MONSTER_H
