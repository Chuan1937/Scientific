#ifndef ITEM_H
#define ITEM_H

#include <string>

class Item {
public:
    Item(const std::string &name = "");
    void setName(const std::string &name);
    std::string getName() const;
    virtual ~Item() {}

private:
    std::string name;
};

#endif // ITEM_H
