#ifndef CHARACTER_H
#define CHARACTER_H

#include <string>

class Character {
public:
    Character(const std::string &name = "", int hitPoints = 0);
    void setName(const std::string &name);
    std::string getName() const;
    void setHitPoints(int hitPoints);
    int getHitPoints() const;
    void takeHit(int damage);

protected:
    std::string name;
    int hitPoints;
};

#endif // CHARACTER_H
