#ifndef PLAYER_H
#define PLAYER_H

#include "Character.h"
#include "Item.h" // Base class for Treasure, Potion, Weapon
#include "Weapon.h"
#include "Monster.h"
#include <vector>
#include <memory> // For smart pointers

class Player : public Character {
public:
    Player(const std::string &name, int hitPoints);

    // Combat
    bool combat(Monster& monster);
    int getHighestWeaponPower() const;
    
    // Inventory management
    void collectItem(std::unique_ptr<Item> item);
    void listInventory() const;
    void drinkPotions();
    int getScore() const;

    void increaseScore(int points);

    // Collect items from a location
    void collectItems(const std::vector<Item*>& items);

private:
    std::vector<std::unique_ptr<Item>> inventory; // Inventory contains all items
    std::vector<std::unique_ptr<Weapon>> weapons; // Separate inventory for weapons for easy access
    int score;
    
    // Helper function to sort inventory items by name
    void sortInventory();
};

#endif // PLAYER_H
