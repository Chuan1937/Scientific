#include "Potion.h"

Potion::Potion(const std::string &name, int strength) : Item(name), strength(strength) {}

int Potion::getStrength() const {
    return strength;
}
