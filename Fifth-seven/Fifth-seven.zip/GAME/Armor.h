// Armor.h
#ifndef ARMOR_H
#define ARMOR_H

#include "Item.h"

class Armor : public Item {
public:
    Armor(const std::string& name, int protection);
    int getProtection() const;

private:
    int protection;
};

#endif // ARMOR_H
