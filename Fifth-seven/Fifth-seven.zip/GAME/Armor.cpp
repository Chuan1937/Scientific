// Armor.cpp
#include "Armor.h"

Armor::Armor(const std::string& name, int protection) : Item(name), protection(protection) {}

int Armor::getProtection() const {
    return protection;
}
