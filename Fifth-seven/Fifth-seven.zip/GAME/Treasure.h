#ifndef TREASURE_H
#define TREASURE_H

#include "Item.h"

class Treasure : public Item {
public:
    //Treasure(const std::string &name, int value);
    Treasure(const std::string &name, int value) : Item(name), value(value) {}
    int getValue() const;

private:
    int value;
};

#endif // TREASURE_H
