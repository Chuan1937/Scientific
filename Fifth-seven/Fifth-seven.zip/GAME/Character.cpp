#include "Character.h"

Character::Character(const std::string &name, int hitPoints) : name(name), hitPoints(hitPoints) {}

void Character::setName(const std::string &name) {
    this->name = name;
}

std::string Character::getName() const {
    return name;
}

void Character::setHitPoints(int hitPoints) {
    this->hitPoints = hitPoints;
}

int Character::getHitPoints() const {
    return hitPoints;
}

void Character::takeHit(int damage) {
    hitPoints -= damage;
    if (hitPoints < 0) {
        hitPoints = 0;
    }
}

