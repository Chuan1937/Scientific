#ifndef PLAYER_H
#define PLAYER_H

#include "Character.h"
#include "Item.h" // Base class for Treasure, Potion, Weapon
#include "Weapon.h"
#include "Monster.h"
#include <vector>
#include <memory> // For smart pointers

using namespace std;

class Player : public Character {
public:
    Player(const string &name, int hitPoints);

    // Combat
    bool combat(Monster& monster);
    int getHighestWeaponPower() const;
    
    // Inventory management
    void collectItem(unique_ptr<Item> item);
    void listInventory() const;
    void drinkPotions();
    int getScore() const;

    void increaseScore(int points);

    // Collect items from a location
    void collectItems(const vector<Item*>& items);

private:
    vector<unique_ptr<Item>> inventory; // Inventory contains all items
    vector<unique_ptr<Weapon>> weapons; // Separate inventory for weapons for easy access
    int score;
    
    // Helper function to sort inventory items by name
    void sortInventory();
};

#endif // PLAYER_H
