#ifndef LOCATION_H
#define LOCATION_H

#include <string>
#include <vector>
#include <map>
#include "Item.h" // Assuming Item is the base class for specific items like Potion, Weapon, Treasure
#include "Character.h" // Assuming Character class is defined, used here for monsters
#include "Monster.h" 
#include <memory>
using namespace std;

class Location {
public:
    Location(const string &name = "", const string &description = "");

    // Setters and getters for name and description
    void setName(const string &name);
    string getName() const;
    void setDescription(const string &description);
    string getDescription() const;

    // Management of exits
    void addExit(const string &direction, Location *location);
    void getExits() const;

    // Management of items
    void addItem(Item *item);
    //void addItem(unique_ptr<Item> item);
    void delItem(Item *item);
    vector<Item*> getItems() const;
    void clearItems();
    void listItems() const;

    // Management of monsters
    void addMonster(Monster* monster);
    void listMonsters() const;
    void delMonster(Character *monster);

    // Methods for managing monsters
    vector<Monster*>& getMonsters();
    Monster& getStrongestMonster();
    void removeMonster(Monster& monster);

private:
    string name;
    string description;
    vector<Item*> items;
    //vector<unique_ptr<Item>> items; 
    vector<Monster*> monsters; 
    map<string, Location*> exits;

    // Helper function to display sorted items by type
    template <typename T>
    void listItemsOfType() const;
};

#endif // LOCATION_H
