#ifndef CHARACTER_H
#define CHARACTER_H

#include <string>
using namespace std;

class Character {
public:
    Character(const string &name = "", int hitPoints = 0);
    void setName(const string &name);
    string getName() const;
    void setHitPoints(int hitPoints);
    int getHitPoints() const;
    void takeHit(int damage);

protected:
    string name;
    int hitPoints;
};

#endif // CHARACTER_H
