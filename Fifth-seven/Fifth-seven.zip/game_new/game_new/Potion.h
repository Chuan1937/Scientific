#ifndef POTION_H
#define POTION_H

#include "Item.h"

using namespace std;

class Potion : public Item {
public:
    Potion(const string &name, int strength);
    int getStrength() const;

private:
    int strength;
};

#endif // POTION_H
