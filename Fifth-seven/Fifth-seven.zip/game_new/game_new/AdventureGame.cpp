#include <iostream>
#include <string>
#include <map>
#include <cstdlib>  
#include <ctime>    
#include "Player.h"
#include "Monster.h"
#include "Location.h"
#include "Treasure.h"
#include "Potion.h" 
#include "Weapon.h"  
using namespace std;


void setupWorld(map<string, Location>& world);
void linkLocations(map<string, Location>& world);
void createItems(map<string, Location>& world);
void createMonsters(map<string, Location>& world);


int main() {
    srand(static_cast<unsigned int>(time(nullptr)));  // Seed the random number generator

    map<string, Location> world;
    setupWorld(world);
    linkLocations(world);
    createItems(world);
    createMonsters(world);
    // 假设Monster已经在Monster.h中定义
    Monster* boss = new Monster("Dragon Lord", 300, 100);
    world["cave"].addMonster(boss);

    Player player("Hero", 100);  // Player starts with 100 hit points
    Location* currentLocation = &world["clearing"];  // Starting location

    string command;

    // Main game loop
    while (true) {
        cout << "You are in " << currentLocation->getName() << "." << endl;
        cout << currentLocation->getDescription() << endl;

        // Announce items and monsters in the room
        currentLocation->listItems();
        currentLocation->listMonsters();

        // Get command from player
        cout << "What do you want to do? ('fight', 'move', 'collect', 'drink', 'inv', 'quit')" << endl;
        getline(cin, command);

        // Handle fight command
        if (command == "fight") {
            Monster& opponent = currentLocation->getStrongestMonster(); // This will be the boss if in the cave
            bool playerWon = player.combat(opponent);
            if (opponent.getName() == "Dark Overlord" && opponent.getHitPoints() <= 0) {
                cout << "You have defeated the Dark Overlord! The realm is saved!" << endl;
                break;  // End the game as the boss is defeated
            }
            if (!playerWon) {
                cout << "You have been defeated by " << opponent.getName() << ". Game over!" << endl;
                break;  // End the game as the player is defeated
            }
        }
        // Handle movement command
        else if (command == "move") {
            // Implement movement logic based on player input and location exits
            // Example: "move north"
        }
        // Handle collect command
        else if (command == "collect") {
            player.collectItems(currentLocation->getItems());
            currentLocation->clearItems();
        }
        // Handle drink command
        else if (command == "drink") {
            player.drinkPotions();
        }
        // Handle inventory display command
        else if (command == "inv") {
            player.listInventory();
        }
        // Handle quit command
        else if (command == "quit") {
            cout << "Your final score is: " << player.getScore() << endl;
            break;  // Exit the game loop
        }
        // Handle invalid commands
        else {
            cout << "Invalid command, please try again." << endl;
        }
    }

    cout << "Game over! Your final score is: " << player.getScore() << endl;
    return 0;
}


void setupWorld(map<string, Location>& world) {
    world["cave"] = Location("a cave", "The cave walls are cold and wet, with occasional glittering mineral veins.");
    world["temple"] = Location("a temple", "Ancient columns rise towards the sky, surrounded by the remnants of old prayers.");
    world["dungeon"] = Location("a dungeon", "The air is thick with dampness, and the chains on the wall rattle softly.");
    world["castle"] = Location("a castle", "Towering stone walls guard the majestic halls within.");
    world["clearing"] = Location("a clearing", "A peaceful grassy area with a gentle breeze and birdsong.");
    world["hall"] = Location("a great hall", "A vast hall with echoes of grand feasts and battles sung.");
    world["garden"] = Location("a garden", "The garden is blooming with an array of colorful, fragrant flowers.");
    world["library"] = Location("a library", "Rows upon rows of ancient tomes fill the dusty shelves.");
    world["forest"] = Location("a forest", "The dense forest canopy barely allows any light to touch the forest floor.");
    world["house"] = Location("a house", "A quaint little house with a smoking chimney and warm windows.");
    world["ruins"] = Location("some ruins", "Crumbling walls and broken statues are all that remain of a once great structure.");
    world["field"] = Location("a field", "Golden crops sway in the wind, stretching out towards the horizon.");
}

void linkLocations(map<string, Location>& world) {
    // Linking each location to its adjacent locations as exits
    world["cave"].addExit("east", &world["field"]);
    world["field"].addExit("west", &world["cave"]);
    world["field"].addExit("east", &world["forest"]);
    world["forest"].addExit("west", &world["field"]);
    world["forest"].addExit("east", &world["temple"]);
    world["temple"].addExit("west", &world["forest"]);
    world["temple"].addExit("east", &world["clearing"]);
    world["clearing"].addExit("west", &world["temple"]);
    world["clearing"].addExit("east", &world["house"]);
    world["house"].addExit("west", &world["clearing"]);
    world["house"].addExit("east", &world["library"]);
    world["library"].addExit("west", &world["house"]);
    world["library"].addExit("south", &world["garden"]);
    world["garden"].addExit("north", &world["library"]);
    world["garden"].addExit("west", &world["hall"]);
    world["hall"].addExit("east", &world["garden"]);
    world["hall"].addExit("south", &world["castle"]);
    world["castle"].addExit("north", &world["hall"]);
    world["castle"].addExit("south", &world["ruins"]);
    world["ruins"].addExit("north", &world["castle"]);
    world["ruins"].addExit("west", &world["dungeon"]);
    world["dungeon"].addExit("east", &world["ruins"]);
}

// void listInventory(const Player& player) {
//     cout << "Inventory:" << endl;
//     // Call player's method to list all items sorted by type and alphabetically
//     player.listInventory();
// }

void createMonsters(map<string, Location>& world) {
    // Instantiate monsters and add them to the corresponding locations
    world["cave"].addMonster(new Monster("dragon", 15, 100));
    world["field"].addMonster(new Monster("goblin", 10, 100));
    world["dungeon"].addMonster(new Monster("zombie", 8, 100));
    world["temple"].addMonster(new Monster("vampire", 9, 100));
    world["forest"].addMonster(new Monster("banshee", 7, 100));
    world["castle"].addMonster(new Monster("orc", 12, 100));
    world["ruins"].addMonster(new Monster("spectre", 5, 100));
    world["house"].addMonster(new Monster("ghoul", 10, 100)); // First monster in the house
    world["house"].addMonster(new Monster("orc", 12, 100));   // Second monster in the house
    world["hall"].addMonster(new Monster("spectre", 5, 100));
    world["library"].addMonster(new Monster("banshee", 7, 100));
    world["garden"].addMonster(new Monster("ghoul", 10, 100));
}

void createItems(map<string, Location>& world) {
    // Treasures
    world["cave"].addItem(new Treasure("emerald", 40));
    world["field"].addItem(new Treasure("sapphire", 40));
    world["dungeon"].addItem(new Treasure("diamond", 60));
    world["temple"].addItem(new Treasure("gold ring", 60));
    world["forest"].addItem(new Treasure("treasure chest", 200));
    world["castle"].addItem(new Treasure("bag of coins", 50));
    world["ruins"].addItem(new Treasure("ruby", 10));

    // Potions
    world["field"].addItem(new Potion("blue healing potion", 20));
    world["dungeon"].addItem(new Potion("purple healing potion", 30));
    world["temple"].addItem(new Potion("red healing potion", 40));

    // Weapons
    world["forest"].addItem(new Weapon("dagger", 5));
    world["castle"].addItem(new Weapon("sword", 6));
    world["ruins"].addItem(new Weapon("stick", 1));
    world["clearing"].addItem(new Weapon("club", 3));
    world["house"].addItem(new Weapon("crossbow", 10));

}
