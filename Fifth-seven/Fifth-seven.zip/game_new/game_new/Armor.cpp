// Armor.cpp
#include "Armor.h"
using namespace std;

Armor::Armor(const string& name, int protection) : Item(name), protection(protection) {}

int Armor::getProtection() const {
    return protection;
}
