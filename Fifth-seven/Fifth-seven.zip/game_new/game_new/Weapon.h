#ifndef WEAPON_H
#define WEAPON_H

#include "Item.h"
using namespace std;

class Weapon : public Item {
public:
    Weapon(const string &name, int power);
    int getPower() const;  // Ensure this is declared

private:
    int power;
};

#endif // WEAPON_H
