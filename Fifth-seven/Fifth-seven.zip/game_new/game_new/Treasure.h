#ifndef TREASURE_H
#define TREASURE_H

#include "Item.h"
using namespace std;

class Treasure : public Item {
public:
    Treasure(const string &name, int value) : Item(name), value(value) {}

private:
    int value;
};

#endif // TREASURE_H
