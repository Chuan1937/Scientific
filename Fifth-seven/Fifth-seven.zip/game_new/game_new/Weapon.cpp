#include "Weapon.h"
using namespace std;

Weapon::Weapon(const string &name, int power) : Item(name), power(power) {}

int Weapon::getPower() const {
    return power;
}
