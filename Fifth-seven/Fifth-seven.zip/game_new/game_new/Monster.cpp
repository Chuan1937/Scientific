#include "Monster.h"
using namespace std;

Monster::Monster(const string &name, int hitPoints, int value) : Character(name, hitPoints), value(value) {}

int Monster::getValue() const {
    return value;
}
