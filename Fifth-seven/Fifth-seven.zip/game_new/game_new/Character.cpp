#include "Character.h"
using namespace std;

Character::Character(const string &name, int hitPoints) : name(name), hitPoints(hitPoints) {}

void Character::setName(const string &name) {
    this->name = name;
}

string Character::getName() const {
    return name;
}

void Character::setHitPoints(int hitPoints) {
    this->hitPoints = hitPoints;
}

int Character::getHitPoints() const {
    return hitPoints;
}

void Character::takeHit(int damage) {
    hitPoints -= damage;
    if (hitPoints < 0) {
        hitPoints = 0;
    }
}

