#include "Item.h"
using namespace std;

Item::Item(const string &name) : name(name) {}

void Item::setName(const string &name) {
    this->name = name;
}

string Item::getName() const {
    return name;
}
