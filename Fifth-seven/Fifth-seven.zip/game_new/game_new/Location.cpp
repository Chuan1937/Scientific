#include "Location.h"
#include "Treasure.h"
#include "Potion.h"
#include "Weapon.h"
#include <algorithm>
#include <iostream>

using namespace std;

Location::Location(const string &name, const string &description)
    : name(name), description(description) {}

void Location::setName(const string &name) {
    this->name = name;
}

string Location::getName() const {
    return name;
}

void Location::setDescription(const string &description) {
    this->description = description;
}

string Location::getDescription() const {
    return description;
}

void Location::addExit(const string &direction, Location *location) {
    exits[direction] = location;
}

void Location::getExits() const {
    cout << "Available exits from " << name << ": " << endl;
    for (const auto &exit : exits) {
        cout << exit.first << " to " << exit.second->getName() << endl;
    }
}

void Location::addItem(Item *item) {
    items.push_back(item);
}

void Location::delItem(Item *item) {
    items.erase(remove(items.begin(), items.end(), item), items.end());
}

void Location::addMonster(Monster* monster) {
    monsters.push_back(monster);
}

void Location::listMonsters() const {
    if (monsters.empty()) {
        cout << "No monsters here." << endl;
    } else {
        cout << "You encounter the following monsters: ";
        for (const auto& monster : monsters) {
            cout << monster->getName() << " (Hitpoints: " << monster->getHitPoints() << "), ";
        }
        cout << endl;
    }
}


void Location::delMonster(Character *monster) {
    monsters.erase(remove(monsters.begin(), monsters.end(), monster), monsters.end());
}

vector<Item*> Location::getItems() const {
    return items;
}

void Location::clearItems() {
    items.clear();
}

void Location::listItems() const {
    cout << "Treasures: ";
    listItemsOfType<Treasure>();

    cout << "Potions: ";
    listItemsOfType<Potion>();

    cout << "Weapons: ";
    listItemsOfType<Weapon>();
}

template <typename T>
void Location::listItemsOfType() const {
    vector<string> itemNames;
    for (const auto& item : items) {
        if (const T* specificItem = dynamic_cast<const T*>(item)) {
            itemNames.push_back(specificItem->getName());
        }
    }
    sort(itemNames.begin(), itemNames.end());
    for (const auto& name : itemNames) {
        cout << name << ", ";
    }
    cout << endl;
}


vector<Monster*>& Location::getMonsters() {
    return monsters;
}

Monster& Location::getStrongestMonster() {
    if (monsters.empty()) {
        throw runtime_error("No monsters in the location");
    }

    // Sort monsters based on their hit points (assuming higher HP means stronger)
    sort(monsters.begin(), monsters.end(), [](const Monster* lhs, const Monster* rhs) {
        return lhs->getHitPoints() > rhs->getHitPoints();
    });

    return *monsters.front(); // Strongest monster after sorting
}

void Location::removeMonster(Monster& monster) {
    auto it = find_if(monsters.begin(), monsters.end(), [&monster](const Monster* m) {
        return m == &monster;
    });

    if (it != monsters.end()) {
        // Handle memory management if necessary
        delete *it; // Assuming raw pointers, use smart pointers to avoid this
        monsters.erase(it);
    }
}
