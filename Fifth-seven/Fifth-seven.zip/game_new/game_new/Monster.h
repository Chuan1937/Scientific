#ifndef MONSTER_H
#define MONSTER_H

#include "Character.h"
using namespace std;

class Monster : public Character {
public:
    Monster(const string &name, int hitPoints, int value);

    int getValue() const;

private:
    int value;
};

#endif // MONSTER_H
