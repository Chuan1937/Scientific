#ifndef ITEM_H
#define ITEM_H

#include <string>
using namespace std;

class Item {
public:
    Item(const string &name = "");
    void setName(const string &name);
    string getName() const;
    virtual ~Item() {}

private:
    string name;
};

#endif // ITEM_H
