```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import scienceplots
```


```python
data=pd.read_excel('CW_Data.xlsx',sheet_name='Sheet2')
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Gender</th>
      <th>Programme</th>
      <th>Grade</th>
      <th>Total</th>
      <th>MCQ</th>
      <th>Q1</th>
      <th>Q2</th>
      <th>Q3</th>
      <th>Q4</th>
      <th>Q5</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>3</td>
      <td>3</td>
      <td>45.0</td>
      <td>21</td>
      <td>8</td>
      <td>4</td>
      <td>2</td>
      <td>10.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>3</td>
      <td>3</td>
      <td>43.0</td>
      <td>21</td>
      <td>4</td>
      <td>2</td>
      <td>8</td>
      <td>8.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>4</td>
      <td>2</td>
      <td>26.0</td>
      <td>24</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>30.0</td>
      <td>24</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0.0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>27.0</td>
      <td>21</td>
      <td>0</td>
      <td>2</td>
      <td>4</td>
      <td>0.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>614</th>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>55.0</td>
      <td>33</td>
      <td>6</td>
      <td>4</td>
      <td>4</td>
      <td>8.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>615</th>
      <td>2</td>
      <td>4</td>
      <td>2</td>
      <td>41.0</td>
      <td>27</td>
      <td>6</td>
      <td>4</td>
      <td>4</td>
      <td>0.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>616</th>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>73.0</td>
      <td>36</td>
      <td>8</td>
      <td>8</td>
      <td>11</td>
      <td>10.0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>617</th>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>77.0</td>
      <td>42</td>
      <td>8</td>
      <td>8</td>
      <td>6</td>
      <td>10.0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>618</th>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>22.0</td>
      <td>12</td>
      <td>4</td>
      <td>0</td>
      <td>4</td>
      <td>2.0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>619 rows × 10 columns</p>
</div>



# task 1


```python
from sklearn import model_selection
predictors = ['Gender','Grade','Total','MCQ','Q1','Q2','Q3','Q4','Q5']

x_train, x_test, y_train, y_test = model_selection.train_test_split(data[predictors], data['Programme'], test_size = 0.25, random_state = 1234)

from sklearn.model_selection import GridSearchCV
from sklearn import tree

max_depth=[2,3, 4, 5, 6, 7, 8, 9, 10]
min_samples_split=[2, 4, 6, 8, 10]
min_samples_leaf=[ 3, 4, 5, 6, 7, 8, 9, 10]

parameters = {'max_depth':max_depth, 'min_samples_split':min_samples_split, 'min_samples_leaf':min_samples_leaf}

grid_dtcateg = GridSearchCV(estimator=tree.DecisionTreeClassifier(), param_grid=parameters, cv=10)
grid_dtcateg.fit(x_train, y_train)

print(grid_dtcateg.best_params_)

```


    ---------------------------------------------------------------------------

    KeyboardInterrupt                         Traceback (most recent call last)

    Cell In[12], line 16
         13 parameters = {'max_depth':max_depth, 'min_samples_split':min_samples_split, 'min_samples_leaf':min_samples_leaf}
         15 grid_dtcateg = GridSearchCV(estimator=tree.DecisionTreeClassifier(), param_grid=parameters, cv=10)
    ---> 16 grid_dtcateg.fit(x_train, y_train)
         18 print(grid_dtcateg.best_params_)
    

    File D:\APP\Miniconda\lib\site-packages\sklearn\model_selection\_search.py:875, in BaseSearchCV.fit(self, X, y, groups, **fit_params)
        869     results = self._format_results(
        870         all_candidate_params, n_splits, all_out, all_more_results
        871     )
        873     return results
    --> 875 self._run_search(evaluate_candidates)
        877 # multimetric is determined here because in the case of a callable
        878 # self.scoring the return type is only known after calling
        879 first_test_score = all_out[0]["test_scores"]
    

    File D:\APP\Miniconda\lib\site-packages\sklearn\model_selection\_search.py:1389, in GridSearchCV._run_search(self, evaluate_candidates)
       1387 def _run_search(self, evaluate_candidates):
       1388     """Search all candidates in param_grid"""
    -> 1389     evaluate_candidates(ParameterGrid(self.param_grid))
    

    File D:\APP\Miniconda\lib\site-packages\sklearn\model_selection\_search.py:822, in BaseSearchCV.fit.<locals>.evaluate_candidates(candidate_params, cv, more_results)
        814 if self.verbose > 0:
        815     print(
        816         "Fitting {0} folds for each of {1} candidates,"
        817         " totalling {2} fits".format(
        818             n_splits, n_candidates, n_candidates * n_splits
        819         )
        820     )
    --> 822 out = parallel(
        823     delayed(_fit_and_score)(
        824         clone(base_estimator),
        825         X,
        826         y,
        827         train=train,
        828         test=test,
        829         parameters=parameters,
        830         split_progress=(split_idx, n_splits),
        831         candidate_progress=(cand_idx, n_candidates),
        832         **fit_and_score_kwargs,
        833     )
        834     for (cand_idx, parameters), (split_idx, (train, test)) in product(
        835         enumerate(candidate_params), enumerate(cv.split(X, y, groups))
        836     )
        837 )
        839 if len(out) < 1:
        840     raise ValueError(
        841         "No fits were performed. "
        842         "Was the CV iterator empty? "
        843         "Were there no candidates?"
        844     )
    

    File D:\APP\Miniconda\lib\site-packages\joblib\parallel.py:1088, in Parallel.__call__(self, iterable)
       1085 if self.dispatch_one_batch(iterator):
       1086     self._iterating = self._original_iterator is not None
    -> 1088 while self.dispatch_one_batch(iterator):
       1089     pass
       1091 if pre_dispatch == "all" or n_jobs == 1:
       1092     # The iterable was consumed all at once by the above for loop.
       1093     # No need to wait for async callbacks to trigger to
       1094     # consumption.
    

    File D:\APP\Miniconda\lib\site-packages\joblib\parallel.py:901, in Parallel.dispatch_one_batch(self, iterator)
        899     return False
        900 else:
    --> 901     self._dispatch(tasks)
        902     return True
    

    File D:\APP\Miniconda\lib\site-packages\joblib\parallel.py:819, in Parallel._dispatch(self, batch)
        817 with self._lock:
        818     job_idx = len(self._jobs)
    --> 819     job = self._backend.apply_async(batch, callback=cb)
        820     # A job can complete so quickly than its callback is
        821     # called before we get here, causing self._jobs to
        822     # grow. To ensure correct results ordering, .insert is
        823     # used (rather than .append) in the following line
        824     self._jobs.insert(job_idx, job)
    

    File D:\APP\Miniconda\lib\site-packages\joblib\_parallel_backends.py:208, in SequentialBackend.apply_async(self, func, callback)
        206 def apply_async(self, func, callback=None):
        207     """Schedule a func to be run"""
    --> 208     result = ImmediateResult(func)
        209     if callback:
        210         callback(result)
    

    File D:\APP\Miniconda\lib\site-packages\joblib\_parallel_backends.py:597, in ImmediateResult.__init__(self, batch)
        594 def __init__(self, batch):
        595     # Don't delay the application, to avoid keeping the input
        596     # arguments in memory
    --> 597     self.results = batch()
    

    File D:\APP\Miniconda\lib\site-packages\joblib\parallel.py:288, in BatchedCalls.__call__(self)
        284 def __call__(self):
        285     # Set the default nested backend to self._backend but do not set the
        286     # change the default number of processes to -1
        287     with parallel_backend(self._backend, n_jobs=self._n_jobs):
    --> 288         return [func(*args, **kwargs)
        289                 for func, args, kwargs in self.items]
    

    File D:\APP\Miniconda\lib\site-packages\joblib\parallel.py:288, in <listcomp>(.0)
        284 def __call__(self):
        285     # Set the default nested backend to self._backend but do not set the
        286     # change the default number of processes to -1
        287     with parallel_backend(self._backend, n_jobs=self._n_jobs):
    --> 288         return [func(*args, **kwargs)
        289                 for func, args, kwargs in self.items]
    

    File D:\APP\Miniconda\lib\site-packages\sklearn\utils\fixes.py:117, in _FuncWrapper.__call__(self, *args, **kwargs)
        115 def __call__(self, *args, **kwargs):
        116     with config_context(**self.config):
    --> 117         return self.function(*args, **kwargs)
    

    File D:\APP\Miniconda\lib\site-packages\sklearn\model_selection\_validation.py:678, in _fit_and_score(estimator, X, y, scorer, train, test, verbose, parameters, fit_params, return_train_score, return_parameters, return_n_test_samples, return_times, return_estimator, split_progress, candidate_progress, error_score)
        674     estimator = estimator.set_params(**cloned_parameters)
        676 start_time = time.time()
    --> 678 X_train, y_train = _safe_split(estimator, X, y, train)
        679 X_test, y_test = _safe_split(estimator, X, y, test, train)
        681 result = {}
    

    File D:\APP\Miniconda\lib\site-packages\sklearn\utils\metaestimators.py:236, in _safe_split(estimator, X, y, indices, train_indices)
        233     X_subset = _safe_indexing(X, indices)
        235 if y is not None:
    --> 236     y_subset = _safe_indexing(y, indices)
        237 else:
        238     y_subset = None
    

    File D:\APP\Miniconda\lib\site-packages\sklearn\utils\__init__.py:354, in _safe_indexing(X, indices, axis)
        348     raise ValueError(
        349         "Specifying the columns using strings is only supported for "
        350         "pandas DataFrames"
        351     )
        353 if hasattr(X, "iloc"):
    --> 354     return _pandas_indexing(X, indices, indices_dtype, axis=axis)
        355 elif hasattr(X, "shape"):
        356     return _array_indexing(X, indices, indices_dtype, axis=axis)
    

    File D:\APP\Miniconda\lib\site-packages\sklearn\utils\__init__.py:196, in _pandas_indexing(X, key, key_dtype, axis)
        191     key = np.asarray(key)
        193 if key_dtype == "int" and not (isinstance(key, slice) or np.isscalar(key)):
        194     # using take() instead of iloc[] ensures the return value is a "proper"
        195     # copy that will not raise SettingWithCopyWarning
    --> 196     return X.take(key, axis=axis)
        197 else:
        198     # check whether we should index with loc or iloc
        199     indexer = X.iloc if key_dtype == "int" else X.loc
    

    File D:\APP\Miniconda\lib\site-packages\pandas\core\series.py:804, in Series.take(self, indices, axis, is_copy, **kwargs)
        802 indices = ensure_platform_int(indices)
        803 new_index = self.index.take(indices)
    --> 804 new_values = self._values.take(indices)
        806 result = self._constructor(new_values, index=new_index, fastpath=True)
        807 return result.__finalize__(self, method="take")
    

    KeyboardInterrupt: 



```python

from sklearn import metrics
from sklearn.model_selection import GridSearchCV
from sklearn import tree
CART_Classifier = tree.DecisionTreeClassifier(max_depth=2, min_samples_leaf=3, min_samples_split=2)
decision_tree = CART_Classifier.fit(x_train, y_train)
pred=CART_Classifier.predict(x_test)
print('模型在测试集上的预测准确率为：\n',metrics.accuracy_score(y_test, pred))
print('模型在训练集上的预测准确率为：\n',metrics.accuracy_score(y_train, CART_Classifier.predict(x_train)))

    
from sklearn.tree import export_graphviz
from IPython.display import Image
import pydotplus
from six import StringIO

# 绘制决策树
dot_data = StringIO()
export_graphviz(
    decision_tree,
    out_file=dot_data,  
    feature_names=predictors,
    class_names=['1','2','3','4'],  
    filled=True,  # 添加filled=True来为节点添加颜色
    rounded=True,  
    special_characters=True
)
# 决策树展现
graph = pydotplus.graph_from_dot_data(dot_data.getvalue())
Image(graph.create_png()) 
# 导出决策树图像为svg
graph.write_svg('Decision tree_2_3_2.svg')

```

    模型在测试集上的预测准确率为：
     0.5741935483870968
    模型在训练集上的预测准确率为：
     0.6293103448275862
    




    True



# task 2


```python
from sklearn import svm
import pandas as pd
from sklearn import model_selection
from sklearn import metrics

letters=pd.read_excel('CW_Data.xlsx',sheet_name='Sheet2')
predictors = ['Gender','Grade','Total','MCQ','Q1','Q2','Q3','Q4','Q5']
X_train, X_test, y_train, y_test = model_selection.train_test_split(letters[predictors], letters['Programme'],test_size=0.25, random_state=1234)

```


```python

'''使用网格搜索法，选择线性可分SVM“类”中的最佳C值'''
C = [0.05, 0.1, 0.5, 1, 2, 5]
parameters = {'C': C}
grid_linear_svc = model_selection.GridSearchCV(estimator=svm.LinearSVC(), param_grid=parameters, scoring='accuracy',
                                               cv=5, verbose=1)
# 模型在训练数据集上的拟合
grid_linear_svc.fit(X_train, y_train)
# 返回交叉验证后的最佳参数值
print(grid_linear_svc.best_params_)
print(grid_linear_svc.best_score_)

# 模型在测试集上的预测
pred_linear_svc = grid_linear_svc.predict(X_test)
# 模型的预测准确率
print('预测准确率：',metrics.accuracy_score(y_test, pred_linear_svc))
```


```python
'''使用网格搜索法，选择非线性SVM“类”中的最佳C值'''
kernel = ['rbf', 'linear', 'poly', 'sigmoid']
#以上四种为非线性SVM的几种常用的SVM核函数：[径向基核函数(高斯核函数),线性核函数,多项式核函数,,Sigmoid核函数]
C = [0.1, 0.5, 1, 2, 5]
parameters = {'kernel': kernel, 'C': C}
grid_svc = model_selection.GridSearchCV(estimator=svm.SVC(), param_grid=parameters, scoring='accuracy', cv=5, verbose=1)
# 模型在训练数据集上的拟合
grid_svc.fit(X_train, y_train)
# 返回交叉验证后的最佳参数值
print(grid_svc.best_params_, grid_svc.best_score_)

# 模型在测试集上的预测
pred_svc = grid_svc.predict(X_test)
# 模型的预测准确率
print('预测准确率',metrics.accuracy_score(y_test, pred_svc))
```

    Fitting 5 folds for each of 20 candidates, totalling 100 fits
    {'C': 0.5, 'kernel': 'linear'} 0.6357643758765779
    预测准确率 0.5612903225806452
    

如上结果所示，经过5重交叉验证后，发现最佳的惩罚系数C为0.5，
最佳的核函数为线性核函数linear。其SVM表现了极佳的效果，模型在训练数据集上的平均准确率高达
63.58%，而且其在测试数据集的预测准确率为56.13%，

# task 3


```python
# 导入第三方包
import pandas as pd

# 读取数据
mushrooms = pd.read_excel('CW_Data.xlsx',sheet_name='Sheet2')


from sklearn import model_selection

# 将数据集拆分为训练集合测试集
Predictors =  ['Gender','Grade','Total','MCQ','Q1','Q2','Q3','Q4','Q5']
X_train, X_test, y_train, y_test = model_selection.train_test_split(mushrooms[Predictors], mushrooms['Programme'],
                                                                    test_size=0.25, random_state=10)

from sklearn import naive_bayes
from sklearn import metrics
import seaborn as sns
import matplotlib.pyplot as plt

# 构建多项式贝叶斯分类器的“类”
mnb = naive_bayes.MultinomialNB()
# 基于训练数据集的拟合
mnb.fit(X_train, y_train)
# 基于测试数据集的预测
mnb_pred = mnb.predict(X_test)
# 构建混淆矩阵
cm = pd.crosstab(mnb_pred, y_test)
# 绘制混淆矩阵图


# 模型的预测准确率
print('模型的准确率为：\n', metrics.accuracy_score(y_test, mnb_pred))
#print('模型的评估报告：\n', metrics.classification_report(y_test, mnb_pred))



```

    模型的准确率为：
     0.4838709677419355
    


```python
import pandas as pd

# 读入评论数据
from sklearn import model_selection
from sklearn import naive_bayes
from sklearn import metrics
import matplotlib.pyplot as plt
import seaborn as sns
mushrooms = pd.read_excel('CW_Data.xlsx',sheet_name='Sheet2')


from sklearn import model_selection

# 将数据集拆分为训练集合测试集
Predictors =  ['Gender','Grade','Total','MCQ','Q1','Q2','Q3','Q4','Q5']
X_train, X_test, y_train, y_test = model_selection.train_test_split(mushrooms[Predictors], mushrooms['Programme'],
                                                                    test_size=0.25, random_state=10)
# 构建伯努利贝叶斯分类器
bnb = naive_bayes.BernoulliNB()
# 模型在训练数据集上的拟合
bnb.fit(X_train, y_train)
# 模型在测试数据集上的预测
bnb_pred = bnb.predict(X_test)
# 构建混淆矩阵
cm = pd.crosstab(bnb_pred, y_test)

# 模型的预测准确率
print('模型的准确率为：\n', metrics.accuracy_score(y_test, bnb_pred))



```

    模型的准确率为：
     0.5032258064516129
    

# task 4


```python
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn import model_selection
from sklearn.metrics import accuracy_score
predictors = ['Gender','Grade','Total','MCQ','Q1','Q2','Q3','Q4','Q5']

X_train, X_test, Y_train, Y_test = model_selection.train_test_split(data[predictors], data['Programme'], test_size = 0.25, random_state = 1234)
#采用2，3，2的决策树
tree = DecisionTreeClassifier(criterion='gini', max_depth=2, min_samples_split=3, min_samples_leaf=2)

ada = AdaBoostClassifier(base_estimator = tree, #指定基分类器
                         algorithm='SAMME',#这里还可以指定其他分类器，如感知器、支持向量机、逻辑斯蒂回归等
                        n_estimators = 500,    #子分类器个数
                        learning_rate=0.1,
                        random_state = 1) #random_state参数指定分类器训练时使用的随机算法的随机种子
ada = ada.fit(X_train, Y_train)
Y_train_pred = ada.predict(X_train)
Y_test_pred = ada.predict(X_test)
accuracy_score(Y_train, Y_train_pred)  #得到训练集上准确率
accuracy_score(Y_test, Y_test_pred)    #得到测试集上准确率
```

    D:\APP\Miniconda\lib\site-packages\sklearn\ensemble\_base.py:166: FutureWarning: `base_estimator` was renamed to `estimator` in version 1.2 and will be removed in 1.4.
      warnings.warn(
    




    0.5612903225806452




```python
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn import model_selection
from sklearn.metrics import accuracy_score
from sklearn import svm
predictors = ['Gender','Grade','Total','MCQ','Q1','Q2','Q3','Q4','Q5']

X_train, X_test, Y_train, Y_test = model_selection.train_test_split(data[predictors], data['Programme'], test_size = 0.25, random_state = 1234)
tree = svm.SVC(kernel='linear', C=0.5)
ada = AdaBoostClassifier(base_estimator = tree, #指定基分类器
                         algorithm='SAMME',#这里还可以指定其他分类器，如感知器、支持向量机、逻辑斯蒂回归等
                        n_estimators = 500,    #子分类器个数
                        learning_rate=0.1,
                        random_state = 1) #random_state参数指定分类器训练时使用的随机算法的随机种子
ada = ada.fit(X_train, Y_train)
Y_train_pred = ada.predict(X_train)
Y_test_pred = ada.predict(X_test)
accuracy_score(Y_train, Y_train_pred)  #得到训练集上准确率
accuracy_score(Y_test, Y_test_pred)    #得到测试集上准确率
```

    D:\APP\Miniconda\lib\site-packages\sklearn\ensemble\_base.py:166: FutureWarning: `base_estimator` was renamed to `estimator` in version 1.2 and will be removed in 1.4.
      warnings.warn(
    




    0.47096774193548385




```python
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn import model_selection
from sklearn.metrics import accuracy_score
from sklearn import naive_bayes
predictors = ['Gender','Grade','Total','MCQ','Q1','Q2','Q3','Q4','Q5']

X_train, X_test, Y_train, Y_test = model_selection.train_test_split(data[predictors], data['Programme'], test_size = 0.25, random_state = 1234)
tree = naive_bayes.BernoulliNB()
ada = AdaBoostClassifier(base_estimator = tree, #指定基分类器
                         algorithm='SAMME',#这里还可以指定其他分类器，如感知器、支持向量机、逻辑斯蒂回归等
                        n_estimators = 500,    #子分类器个数
                        learning_rate=0.1,
                        random_state = 1) #random_state参数指定分类器训练时使用的随机算法的随机种子
ada = ada.fit(X_train, Y_train)
Y_train_pred = ada.predict(X_train)
Y_test_pred = ada.predict(X_test)
accuracy_score(Y_train, Y_train_pred)  #得到训练集上准确率
accuracy_score(Y_test, Y_test_pred)    #得到测试集上准确率
```

    D:\APP\Miniconda\lib\site-packages\sklearn\ensemble\_base.py:166: FutureWarning: `base_estimator` was renamed to `estimator` in version 1.2 and will be removed in 1.4.
      warnings.warn(
    




    0.5290322580645161




```python

```
