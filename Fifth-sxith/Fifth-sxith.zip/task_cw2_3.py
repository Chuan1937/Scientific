import pandas as pd
from sklearn import model_selection
from sklearn.model_selection import GridSearchCV
from sklearn import tree
from sklearn import svm
from sklearn import naive_bayes
from sklearn import metrics
from sklearn.ensemble import AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
import warnings
warnings.filterwarnings("ignore")

#%%
dt=pd.read_excel('CW_Data.xlsx',sheet_name='Sheet2')

PRE = ['Gender','Grade','Total','MCQ','Q1','Q2','Q3','Q4','Q5']
x_train, x_test, y_train, y_test = model_selection.train_test_split(dt[PRE], dt['Programme'], test_size = 0.25, random_state = 1234)

max_depth=[1,2,3, 4, 5, 6, 7, 8, 9, 10]
min_samples_split=[1,2,3,4, 6, 8, 10]
min_samples_leaf=[1,2,3,4, 5, 6, 7, 8, 9, 10]

parameters = {'max_depth':max_depth, 'min_samples_split':min_samples_split, 'min_samples_leaf':min_samples_leaf}

gt = GridSearchCV(estimator=tree.DecisionTreeClassifier(), param_grid=parameters, cv=10)
gt.fit(x_train, y_train)

gt.best_params_
#%%
CT = tree.DecisionTreeClassifier(max_depth=2, min_samples_leaf=1, min_samples_split=1)
decision_tree = CT.fit(x_train, y_train)
pred=CT.predict(x_test)
print('accuracy in test data：\n',metrics.accuracy_score(y_test, pred))
print('accuracy in train data：\n',metrics.accuracy_score(y_train, CT.predict(x_train)))
#%%
CT = tree.DecisionTreeClassifier(max_depth=5, min_samples_leaf=3, min_samples_split=2)
decision_tree = CT.fit(x_train, y_train)
pred=CT.predict(x_test)
print('accuracy in test data：\n',metrics.accuracy_score(y_test, pred))
print('accuracy in train data：\n',metrics.accuracy_score(y_train, CT.predict(x_train)))
#%%
dt2=pd.read_excel('CW_Data.xlsx',sheet_name='Sheet2')
PRE = ['Gender','Grade','Total','MCQ','Q1','Q2','Q3','Q4','Q5']
X_train, X_test, y_train, y_test = model_selection.train_test_split(dt2[PRE], dt2['Programme'],test_size=0.25, random_state=4321)
#%%
kernel = ['rbf', 'linear', 'poly', 'sigmoid']
C = [0.01,0.1, 0.5, 1, 2, 5,10]
parameters = {'kernel': kernel, 'C': C}
gs = model_selection.GridSearchCV(estimator=svm.SVC(), param_grid=parameters, scoring='accuracy', cv=5, verbose=2)
gs.fit(X_train, y_train)
print(gs.best_params_, gs.best_score_)
pred_svc = gs.predict(X_test)
print('accuracy',metrics.accuracy_score(y_test, pred_svc))
#%%
dt3 = pd.read_excel('CW_Data.xlsx',sheet_name='Sheet2')

PRE =  ['Gender','Grade','Total','MCQ','Q1','Q2','Q3','Q4','Q5']
X_train, X_test, y_train, y_test = model_selection.train_test_split(dt3[PRE], dt3['Programme'],
                                                                    test_size=0.25, random_state=1234)
mnb = naive_bayes.MultinomialNB()
mnb.fit(X_train, y_train)
mnb_pred = mnb.predict(X_test)
print('accuracy：\n', metrics.accuracy_score(y_test, mnb_pred))
#%%
dt3 = pd.read_excel('CW_Data.xlsx',sheet_name='Sheet2')
PRE =  ['Gender','Grade','Total','MCQ','Q1','Q2','Q3','Q4','Q5']
X_train, X_test, y_train, y_test = model_selection.train_test_split(dt3[PRE], dt3['Programme'],
                                                                    test_size=0.25, random_state=10)
bnb = naive_bayes.BernoulliNB()
bnb.fit(X_train, y_train)
bnb_pred = bnb.predict(X_test)
print('accuracy：\n', metrics.accuracy_score(y_test, bnb_pred))
#%%
PRE = ['Gender','Grade','Total','MCQ','Q1','Q2','Q3','Q4','Q5']
X_train, X_test, Y_train, Y_test = model_selection.train_test_split(dt[PRE], dt['Programme'], test_size = 0.25, random_state = 1234)
tree = DecisionTreeClassifier(criterion='gini', max_depth=5, min_samples_split=3, min_samples_leaf=2)

ada = AdaBoostClassifier(base_estimator = tree,
                         algorithm='SAMME',
                        n_estimators = 500,
                        learning_rate=0.1,
                        random_state = 1)
ada = ada.fit(X_train, Y_train)
Y_train_pred = ada.predict(X_train)
Y_test_pred = ada.predict(X_test)
print('accuracy in train data \n',accuracy_score(Y_train, Y_train_pred))
print('accuracy in test data \n',accuracy_score(Y_test, Y_test_pred)  )
#%%
PRE = ['Gender','Grade','Total','MCQ','Q1','Q2','Q3','Q4','Q5']

X_train, X_test, Y_train, Y_test = model_selection.train_test_split(dt[PRE], dt['Programme'], test_size = 0.25, random_state = 1234)
tree = svm.SVC(kernel='linear', C=5)
ada = AdaBoostClassifier(base_estimator = tree,
                         algorithm='SAMME',
                        n_estimators = 500,
                        learning_rate=0.1,
                        random_state = 1)
ada = ada.fit(X_train, Y_train)
Y_train_pred = ada.predict(X_train)
Y_test_pred = ada.predict(X_test)
print('accuracy in train data \n',accuracy_score(Y_train, Y_train_pred))
print('accuracy in test data \n',accuracy_score(Y_test, Y_test_pred)  )
#%%
PRE = ['Gender','Grade','Total','MCQ','Q1','Q2','Q3','Q4','Q5']
X_train, X_test, Y_train, Y_test = model_selection.train_test_split(dt[PRE], dt['Programme'], test_size = 0.25, random_state = 1234)
tree = naive_bayes.BernoulliNB()
ada = AdaBoostClassifier(base_estimator = tree,
                         algorithm='SAMME',
                        n_estimators = 500,
                        learning_rate=0.1,
                        random_state = 1)
ada = ada.fit(X_train, Y_train)
Y_train_pred = ada.predict(X_train)
Y_test_pred = ada.predict(X_test)
print('accuracy in train data \n',accuracy_score(Y_train, Y_train_pred))
print('accuracy in test data \n',accuracy_score(Y_test, Y_test_pred)  )
