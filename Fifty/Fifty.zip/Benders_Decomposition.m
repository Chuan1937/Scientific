%% Solve a Stochastic 2-stage Linear Programming Problem using Bender's Decomposition

% Made by Jeonghun Song (Turbomachinery Laboratory, Seoul National University)
% Problem: Example 4.2 in Introduction to Stochastic Programming by Birge and Louveaux (2nd Ed.)

clear all; clc;

% Formulate 1st stage matrices

c = [3 2 1]; % objective function (The last term: coefficient of theta, automatically becomes 1)

Aineq = []; bineq = []; Aeq = []; beq = []; % Constraints 

lb = [zeros(1,2) -1e9]; % lower bound, set lb of theta as a big negative number instead of -inf (-inf makes the problem unbounded) (Note: 1e10 makes error in some PCs)
ub = [inf inf inf]; % upper bound


% Formulate 2nd stage matrices (Sparse matrices recommended)
% WARNING: All inequality constraints should be converted to equality constraints using slack variables, the required format is Wy = h - Tx with nonnegative variables

num_sc = 2; prob = [0.5 0.5]; % number of scenarios & probability of each scenario

q{1} = [-15 -12 zeros(1,6)]; % zeros(1,6) for slack variables
q{2} = q{1}; % q does not change in different realizations

T{1} = sparse([-eye(2); zeros(4,2)]);
T{2} = T{1}; % T does not change in different realizations

h{1} = sparse([0 0 4 -0.8*4 4 -0.8*4]');
h{2} = sparse([0 0 6 -0.8*6 8 -0.8*8]');

W = sparse([[3 2; 2 5; 1 0; -1 0; 0 1; 0 -1] eye(6)]); % eye(6) for slack variables


% Optimization
%===================== DO NOT REVISE =====================
[cut_feas_A, cut_feas_b] = feasibilitycut(c,Aineq,bineq,Aeq,beq,lb,ub,T,h,W,num_sc);
[x, theta] = optimization(c,Aineq,bineq,Aeq,beq,lb,ub,q,T,h,W,cut_feas_A,cut_feas_b,num_sc,prob);
clear cut_feas_A cut_feas_b;
%===================== DO NOT REVISE =====================


% Results (Modify depending on the problem)

optimalset = x
min_fval = c(1:(numel(c)-1))*x + c(numel(c))*theta





%% User-defined function for generating feasibility cuts

function [cut_feas_A, cut_feas_b] = feasibilitycut(c,Aineq,bineq,Aeq,beq,lb,ub,T,h,W,num_sc)

num_vars_x = numel(c) - 1; % excluding theta
num_vars_y = numel(W(1,:)); % including slack variables
num_constraints = numel(T{1}(:,1));

cut_feas_A = []; cut_feas_b = [];

while(1)

% 1st problem

x = linprog(c,[Aineq; cut_feas_A],[bineq; cut_feas_b],Aeq,beq,lb,ub);
x = x(1:num_vars_x); % x which goes to 2nd stage (remove theta)

% Feasibility check & Generating feasibility cuts if necessary

for sc = 1:num_sc
    
    obj_dual = [(h{sc}-T{sc}*x)' -(h{sc}-T{sc}*x)']; % convert unconstrained pi to (pi_+) - (pi_-), both (pi_+) and (pi_-) are nonnegative 
    dualvars_feas_temp{sc} = linprog(-obj_dual, [W' -W'; ones(1,num_constraints*2)], [zeros(num_vars_y,1); 1], [], [], zeros(1,num_constraints*2), []); % maximization, minus to obj. func.
    feascheck(sc) = obj_dual * dualvars_feas_temp{sc};
     
    if feascheck(sc) > eps % positive dual function (applied eps for tolerance issue) -> Generating feasibility cut             
        dualvars_feas{sc} = dualvars_feas_temp{sc}(1:num_constraints) - dualvars_feas_temp{sc}(num_constraints+1:num_constraints*2); % get pi = (pi_+) - (pi_-) to make feasibility cuts
        cut_feas_A = [cut_feas_A; -dualvars_feas{sc}'*T{sc} 0]; % 0 corresponds to theta
        cut_feas_b = [cut_feas_b; -dualvars_feas{sc}'*h{sc}];
    end
    
end

if max(feascheck) <= eps
    break; % nonpositive for all realizations -> return feasibility cuts and end this procedure
end

end

end



%% User-defined function for optimization with generating optimality cuts

function [x, theta] = optimization(c,Aineq,bineq,Aeq,beq,lb,ub,q,T,h,W,cut_feas_A,cut_feas_b,num_sc,prob)

num_vars_x = numel(c) - 1; % excluding theta
num_vars_y = numel(W(1,:)); % including slack variables

cut_opt_A = []; cut_opt_b = [];
theta = -1e9; Q = theta+1; % initially Q > theta

while(Q > theta) % terminate if theta >= Q

% 1st problem

x = linprog(c,[Aineq; cut_feas_A; cut_opt_A],[bineq; cut_feas_b; cut_opt_b],Aeq,beq,lb,ub);
theta = x(num_vars_x+1);
x = x(1:num_vars_x);

% 2nd problem

Q_temp = 0;
for sc = 1:num_sc    
    [y, qval(sc)] = linprog(q{sc},[],[],W,h{sc}-T{sc}*x,zeros(1,num_vars_y),inf*ones(1,num_vars_y));
    Q_temp = Q_temp + prob(sc)*qval(sc);
end
Q = Q_temp; % compare theta and Q
    
% Generating an optimality cut 

alpha = 0; beta = zeros(1,num_vars_x);
for sc = 1:num_sc
    
    obj_dual = (h{sc}-T{sc}*x)';
    dualvars_opt{sc} = linprog(-obj_dual, W', q{sc}, [], []); % maximization, minus to obj. func.
    
    alpha = alpha + prob(sc)*dualvars_opt{sc}'*h{sc};
    beta = beta + prob(sc)*dualvars_opt{sc}'*(-T{sc});  
    
end

cut_opt_A = [cut_opt_A; beta -1]; % -1 corresponding to theta
cut_opt_b = [cut_opt_b; -alpha];

end

end