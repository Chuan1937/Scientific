% 定义线性方程组的系数矩阵和常数向量
A = [2, 1, 0, 0, 0; 5/14, 2, 9/14, 0, 0; 0, 3/5, 2, 2/5, 0; 0, 0, 3/7, 2, 4/7; 0, 0, 0, 1, 2];
b = [-5.5200; -4.3144; -3.2664; -2.4287; -2.1150];

% 获取系数矩阵 A 的维度
n = size(A, 1);

% 初始化追赶法所需的中间变量
alpha = zeros(n, 1);
beta = zeros(n, 1);
gamma = zeros(n, 1);
d = zeros(n, 1);
x = zeros(n, 1);

% 计算追赶法中的中间变量
alpha(1) = A(1, 1);
beta(1) = A(1, 2) / alpha(1);
gamma(1) = b(1) / alpha(1);

for i = 2:n-1
    alpha(i) = A(i, i) - A(i, i-1) * beta(i-1);
    beta(i) = A(i, i+1) / alpha(i);
    gamma(i) = (b(i) - A(i, i-1) * gamma(i-1)) / alpha(i);
end

alpha(n) = A(n, n) - A(n, n-1) * beta(n-1);
gamma(n) = (b(n) - A(n, n-1) * gamma(n-1)) / alpha(n);

% 回代过程，求解方程组
x(n) = gamma(n);
for i = n-1:-1:1
    x(i) = gamma(i) - beta(i) * x(i+1);
end

% 打印结果
disp('方程组的解为：');
disp(x);
