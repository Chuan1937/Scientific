% 定义线性方程组的系数矩阵 A 和常数向量 b
A = [11, -3, -2; -23, 11, 1; 1, 2, 2];
b = [3; 0; -1];

% 将增广矩阵 [A | b] 构建为增广矩阵 Ab
Ab = [A, b];

% 获取增广矩阵的行数和列数
[m, n] = size(Ab);

% 高斯消元过程
for k = 1:m-1
    % 部分主元素法，选择主元素为当前列中绝对值最大的元素
    [~, max_index] = max(abs(Ab(k:m, k)));
    max_index = max_index + k - 1; % 调整索引为全局索引
    if Ab(max_index, k) == 0
        error('主元素为0，无法继续计算');
    end
    % 交换当前行与主元素所在行
    Ab([k, max_index], :) = Ab([max_index, k], :);
    % 主元素所在行消元
    for i = k+1:m
        factor = Ab(i, k) / Ab(k, k);
        Ab(i, :) = Ab(i, :) - factor * Ab(k, :);
    end
end

% 回代过程，求解方程组
x = zeros(n-1, 1);
x(m) = Ab(m, n) / Ab(m, m);
for i = m-1:-1:1
    x(i) = (Ab(i, n) - Ab(i, i+1:m) * x(i+1:m)) / Ab(i, i);
end

% 打印结果
disp('方程组的解为：');
disp(x);
